//# include <iostream>
//using namespace std;
//void capitalize(char *a);
//int main()
//{
//	char arr[100] = {};
//	char *a = arr;
//	cout << "Enter text : ";
//	cin.getline(arr, 100);
//	cout << "After capitalization : ";
//	capitalize(a);
//}
//void capitalize(char *a)
//{
//	for (int i = 0; a[i] != '\0'; i++)
//	{
//		if (a[i] >= 'a' && a[i] <= 'z')
//		{
//			a[i] -= 32;
//		}
//	}
//	cout << a << endl;
//}