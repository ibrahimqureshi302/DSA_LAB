//#include<iostream>
//using namespace std;
//int main()
//{
//	int a = 0;
//	int b = 0;
//	int *ptr=&a;
//	int *p = &b;
//	cout << "Enter first number:";
//	cin >> *ptr;
//	cout << "Enter second number:";
//	cin >> *p;
//	if (*p > *ptr)
//	{
//		cout << *p << " is greater than " << *ptr;
//	}
//	else
//	{
//		cout << *ptr << " is greater than " << *p;
//	}
//	system("Pause");
//	return 0;
//
//
//
//}