//# include <iostream>
//using namespace std;
//void area(int *a);
//int main()
//{
//	int r = 0;
//	int *a = &r;
//	cout << "Enter side of square : ";
//	cin >> *a;
//	area(a);
//}
//void area(int *a)
//{
//	cout << "area of square is equal to : " << (*a)*(*a) << endl;
//}