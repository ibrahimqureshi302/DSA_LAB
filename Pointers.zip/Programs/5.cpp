//# include <iostream>
//using namespace std;
//void count(int *a);
//int main()
//{
//	int arr[5] = {};
//	int *a = arr;
//	cout << "Enter five numbers : ";
//	for (int i = 0; i < 5; i++)
//	{
//		cin >> a[i];
//	}
//	count(a);
//	system("pause");
//}
//void count(int *a)
//{
//	cout << "reverse of array is : ";
//	for (int i = 4; i >= 0; i--)
//	{
//		cout << a[i] << " ";
//	}
//	cout << endl;
//}