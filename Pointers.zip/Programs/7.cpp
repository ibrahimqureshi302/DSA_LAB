//# include <iostream>
//using namespace std;
//void sum(int *a);
//int main()
//{
//	int arr[8] = {};
//	int *a = arr;
//	cout << "Enter 8 numbers : ";
//	for (int i = 0; i < 8; i++)
//	{
//		cin >> a[i];
//	}
//	sum(a);
//}
//void sum(int *a)
//{
//	int b = 0;
//	for (int i = 0; i < 8; i++)
//	{
//		if (a[i] % 2 == 0)
//		{
//			b = b + a[i];
//		}
//	}
//	cout << "Sum of even numbers is equal to : " << b << endl;
//}