//# include <iostream>
//using namespace std;
//void count(int *a);
//int main()
//{
//	int arr[5] = {};
//	int *a = arr;
//	cout << "Enter five numbers : ";
//	for (int i = 0; i < 5; i++)
//	{
//		cin >> a[i];
//	}
//	count(a);
//	system("pause");
//}
//void count(int *a)
//{
//	int j = 0;
//	for (int i = 0;i<5; i++)
//	{
//		j = j + a[i];
//	}
//	cout << "Total is equal to : " << j << endl;
//}