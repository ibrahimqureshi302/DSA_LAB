//# include <iostream>
//using namespace std;
//void power(int *a , int *b);
//int main()
//{
//	int c = 0;
//	int d = 0;
//	int *a = &c;
//	int *b = &d;
//	cout << "Enter the number whose power you want to find : ";
//	cin >> *a;
//	cout << "Enter the power : ";
//	cin >> *b;
//	power(a, b);
//}
//void power(int *a, int *b)
//{
//	int c = 1;
//	for (int i = 0; i < *b; i++)
//	{
//		c = c*(*a);
//	}
//	cout << c << endl;
//}