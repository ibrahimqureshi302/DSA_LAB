//# include <iostream>
//using namespace std;
//void length(char *a);
//int main()
//{
//	char arr[100] = {};
//	char *a = arr;
//	cout << "Enter text : ";
//	cin.getline(arr , 100);
//	length(a);
//	system("pause");
//}
//void length(char *a)
//{
//	int i = 0;
//	for (i; a[i] != '\0'; i++)
//	{
//
//	}
//	cout << "Length of text is : " << i << endl;
//}